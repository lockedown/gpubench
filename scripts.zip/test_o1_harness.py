#!/usr/bin/env python3
"""Offline test for run_o1_benchmark.py — mocks torch/vllm/transformers.

Simulated engine: first-token latency = 20ms x in-flight requests, so the
P99-TTFT>1500ms ceiling should land near 75 concurrent sessions. Exercises:
ramp + binary search, confirmation repeats, CoV, KV derivation, CSV emit,
and resume-skip on re-run.
"""
import asyncio, csv, os, sys, time, types  # noqa: E401

OUT = "/tmp/o1_test/results.csv"
os.makedirs("/tmp/o1_test", exist_ok=True)
if os.path.exists(OUT):
    os.remove(OUT)

# ── fake torch ────────────────────────────────────────────────────────────────
torch = types.ModuleType("torch")
cuda = types.ModuleType("torch.cuda")
cuda.device_count = lambda: 8
cuda.is_available = lambda: True
cuda.reset_peak_memory_stats = lambda i=None: None
cuda.max_memory_allocated = lambda i=None: 120 * 1024**3
cuda.empty_cache = lambda: None
cuda.can_device_access_peer = lambda i, j: True
torch.cuda = cuda
torch.__version__ = "2.11.0-fake"
version = types.ModuleType("torch.version"); version.cuda = "13.0"
torch.version = version
sys.modules["torch"] = torch
sys.modules["torch.cuda"] = cuda

# ── fake vllm ─────────────────────────────────────────────────────────────────
vllm = types.ModuleType("vllm")
vllm.__version__ = "0.22.1-fake"

class SamplingParams:
    def __init__(self, **kw): self.__dict__.update(kw)

class TokensPrompt:
    def __init__(self, prompt_token_ids): self.prompt_token_ids = prompt_token_ids

class AsyncEngineArgs:
    def __init__(self, **kw): self.__dict__.update(kw)

class _HF:  # hf_config for kv derivation (GQA-style)
    num_hidden_layers = 48
    num_attention_heads = 64
    num_key_value_heads = 8
    hidden_size = 8192
    head_dim = 128

class _ModelConfig: hf_config = _HF()
class _CacheConfig: block_size = 16
class _Core:
    model_config = _ModelConfig()
    cache_config = _CacheConfig()

class FakeOut:
    def __init__(self, n):
        o = types.SimpleNamespace(token_ids=list(range(n)))
        self.outputs = [o]

class AsyncLLMEngine:
    LAT_PER_INFLIGHT = 0.020  # 20ms per in-flight -> interactive ceiling ~75
    OOM_AT = 100              # KV pool "full" beyond 100 in-flight -> mem ceiling 100

    def __init__(self, args): self.args, self.inflight, self.engine = args, 0, _Core()
    @classmethod
    def from_engine_args(cls, ea): return cls(ea)
    def shutdown_background_loop(self): pass

    async def generate(self, prompt, sp, rid):
        self.inflight += 1
        try:
            await asyncio.sleep(0)                    # let the whole batch enter
            if self.inflight > self.OOM_AT:
                raise RuntimeError("CUDA out of memory: KV cache pool exhausted (fake)")
            await asyncio.sleep(self.LAT_PER_INFLIGHT * self.inflight)
            yield FakeOut(1)                          # first token (TTFT)
            for n in (2, 3, 4):
                await asyncio.sleep(0.001)
                yield FakeOut(n)                      # ITL samples
        finally:
            self.inflight -= 1

vllm.SamplingParams, vllm.TokensPrompt, vllm.AsyncEngineArgs = SamplingParams, TokensPrompt, AsyncEngineArgs
ale = types.ModuleType("vllm.engine.async_llm_engine"); ale.AsyncLLMEngine = AsyncLLMEngine
eng = types.ModuleType("vllm.engine")
sys.modules.update({"vllm": vllm, "vllm.engine": eng, "vllm.engine.async_llm_engine": ale})

# ── fake transformers ─────────────────────────────────────────────────────────
tf = types.ModuleType("transformers")
class FakeTok:
    vocab_size = 150000
    all_special_ids = [0, 1, 2]
class AutoTokenizer:
    @staticmethod
    def from_pretrained(*a, **k): return FakeTok()
tf.AutoTokenizer = AutoTokenizer
sys.modules["transformers"] = tf

# ── import the harness ────────────────────────────────────────────────────────
sys.path.insert(0, "/sessions/practical-trusting-fermi/mnt/outputs")
import run_o1_benchmark as h  # noqa: E402

fails = []
def check(name, cond, detail=""):
    print(f"  {'PASS' if cond else 'FAIL'}  {name}" + (f"  [{detail}]" if detail else ""))
    if not cond: fails.append(name)

# ── unit tests ────────────────────────────────────────────────────────────────
print("── unit tests")
br = h.BurstResult(sessions=1, ttft_ms=list(range(1, 101)))
check("percentile p99", br.p99_ttft == 99, f"got {br.p99_ttft}")
check("percentile p50", br.p(br.ttft_ms, 0.5) == 50, f"got {br.p(br.ttft_ms, 0.5)}")

ids1 = h.make_prompt_ids(FakeTok(), 2048, 1234)
ids2 = h.make_prompt_ids(FakeTok(), 2048, 1234)
check("prompt exact length", len(ids1) == 2048)
check("prompt deterministic", ids1 == ids2)
check("prompt avoids specials", not set(ids1) & {0, 1, 2})

os.makedirs("/tmp/o1_test/models/Qwen/Qwen3.5-122B-A10B", exist_ok=True)
p = h.resolve_model_path("Qwen/Qwen3.5-122B-A10B", "/tmp/o1_test/models")
check("resolve_model_path local root", p == "/tmp/o1_test/models/Qwen/Qwen3.5-122B-A10B", str(p))
check("resolve_model_path missing -> None",
      h.resolve_model_path("nope/nope", "/tmp/o1_test/models") is None)

# ── e2e sweep with simulated engine ───────────────────────────────────────────
print("── e2e sweep (simulated ceiling ≈ 75)")
h.PROFILES["quick"] = {"out": 4, "warm": 0, "cap": 0, "reps": 3}
h.MODELS["qwen"]["local_path"] = "/tmp/o1_test/models/Qwen/Qwen3.5-122B-A10B"

sys.argv = ["x", "--models", "qwen", "--context-lengths", "2048", "--block-sizes", "16",
            "--profile", "quick", "--out", OUT, "--operator", "test",
            "--model-root", "/tmp/o1_test/models", "--stagger", "0.001",
            "--max-sessions", "256"]
args = h.parse_args()
info = {"gpu_count": 8, "vllm_version": "0.22.1-fake",
        "driver_version": "580.00-fake", "torch_version": "2.11.0-fake"}

t0 = time.time()
asyncio.run(h.main_async(args, info))
dur = time.time() - t0

rows = list(csv.DictReader(open(OUT)))
check("one CSV row emitted", len(rows) == 1, f"{len(rows)} rows")
r = rows[0]
check("CSV has all manifest fields", list(r.keys()) == h.CSV_FIELDS)
slo = int(r["concurrent_sessions"])
mem = int(r["concurrent_sessions_memory"])
check("interactive ceiling near simulated SLO limit (60-90)", 60 <= slo <= 90, f"slo={slo}")
# fake sessions overlap imperfectly, so peak in-flight lags session count a little
check("memory ceiling found near fake OOM point (95-115)", 95 <= mem <= 115, f"mem={mem}")
check("memory ceiling > interactive ceiling", mem > slo, f"{mem} > {slo}")
check("memory ceiling reason is OOM", r["memory_ceiling_reason"] == "OOM",
      r["memory_ceiling_reason"])
check("p99 TTFT at interactive ceiling <= 1500ms bound",
      float(r["p99_ttft_ms_at_interactive_ceiling"]) <= h.TTFT_CEILING_MS,
      r["p99_ttft_ms_at_interactive_ceiling"])
check("ITL percentiles recorded", r["itl_p50_ms"] != "" and r["itl_p99_ms"] != "")
check("ITL at memory ceiling recorded", r["itl_p99_ms_at_memory_ceiling"] != "")
check("3 repeats completed", r["repeats_completed"] == "3")
check("CoV computed and passes", r["cov_pass"] == "True", f"cov={r['coefficient_of_variation']}")
# GQA kv: 2*48*8*128*2 bytes/tok * 2048 tok = 402,653,184
check("KV bytes/session (config-derived, GQA)",
      r["kv_bytes_per_session_config"] == "402653184", r["kv_bytes_per_session_config"])
check("precision / model_id / scenario",
      (r["precision"], r["model_id"], r["scenario"]) == ("bf16", "qwen3.5-122b-a10b", "server"))
check("stack + versions recorded", "vllm-on-instance/0.22.1-fake" == r["serving_stack"]
      and r["torch_version"] == "2.11.0-fake")

# ── resume: second run must skip the completed cell ───────────────────────────
print("── resume behaviour")
asyncio.run(h.main_async(args, info))
rows2 = list(csv.DictReader(open(OUT)))
check("completed cell skipped on re-run", len(rows2) == 1, f"{len(rows2)} rows")

print(f"\n{len(fails)} failures | e2e sweep wall time {dur:.1f}s")
sys.exit(1 if fails else 0)
